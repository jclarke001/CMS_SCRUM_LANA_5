
Welcome to Paypal Donate Page. Please see the advanced help for more information.

If you're having trouble installing this module, please ensure that your 
tar program is not flattening the directory tree, truncating filenames
or losing files.

Installing the Paypal Donate Page Module:

Place the entirety of this directory in sites/all/modules/paypal_donate

Navigate to administer >> build >> modules. Enable the Paypal Donation Page.

You will now be abled to add new pages / nodes of the content type "Paypal Donation Page". The fastest 
way to create a new donation page is to goto. 

Create Content => Paypal donate page

To add a currency to the list found in the above page, go to Structure => Content Types => PayPal Donate | Manage fields => paypal_donate_currency | Edit
Add new currency in the form of  : Currency Name|COD

Enjoy !

Johnny Mast
mastjohnny@gmail.com
